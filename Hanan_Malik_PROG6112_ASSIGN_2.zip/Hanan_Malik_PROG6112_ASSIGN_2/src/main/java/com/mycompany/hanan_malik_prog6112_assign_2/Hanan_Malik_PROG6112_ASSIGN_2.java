package com.mycompany.hanan_malik_prog6112_assign_2;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.Dimension;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Hanan_Malik_PROG6112_ASSIGN_2 {

    public static void main(String[] args) {
        RescueOperationsUI.run();
    }

    
    // INTERFACE - all rescue types must honour this contract
    
    public interface RescueOperations {
        String STATUS_NEW         = "New Rescue";
        String STATUS_IN_PROGRESS = "Rescue in Progress";
        String STATUS_OBSERVATION = "Under Observation";
        String STATUS_COMPLETED   = "Rescue Completed";

        void startRescue();
        void completeRescue();
        String generateSummary();
    }

    
    // ABSTRACT BASE CLASS - encapsulation + abstraction
    
    public static abstract class RescueCase implements RescueOperations {

        private String rescueCaseId;
        private String animalName;
        private String species;
        private String rescueLocation;
        private String assignedRanger;
        private int numberOfRescueDays;
        private double dailyCareCost;
        private String currentRescueStatus;

        protected RescueCase(String rescueCaseId,
                             String animalName,
                             String species,
                             String rescueLocation,
                             String assignedRanger,
                             int numberOfRescueDays,
                             double dailyCareCost,
                             String currentRescueStatus) {
            this.rescueCaseId = rescueCaseId;
            this.animalName = animalName;
            this.species = species;
            this.rescueLocation = rescueLocation;
            this.assignedRanger = assignedRanger;
            this.numberOfRescueDays = numberOfRescueDays;
            this.dailyCareCost = dailyCareCost;
            this.currentRescueStatus = currentRescueStatus;
        }

        public String getRescueCaseId() { return rescueCaseId; }
        public void setRescueCaseId(String v) { this.rescueCaseId = v; }

        public String getAnimalName() { return animalName; }
        public void setAnimalName(String v) { this.animalName = v; }

        public String getSpecies() { return species; }
        public void setSpecies(String v) { this.species = v; }

        public String getRescueLocation() { return rescueLocation; }
        public void setRescueLocation(String v) { this.rescueLocation = v; }

        public String getAssignedRanger() { return assignedRanger; }
        public void setAssignedRanger(String v) { this.assignedRanger = v; }

        public int getNumberOfRescueDays() { return numberOfRescueDays; }
        public void setNumberOfRescueDays(int v) { this.numberOfRescueDays = v; }

        public double getDailyCareCost() { return dailyCareCost; }
        public void setDailyCareCost(double v) { this.dailyCareCost = v; }

        public String getCurrentRescueStatus() { return currentRescueStatus; }
        public void setCurrentRescueStatus(String v) { this.currentRescueStatus = v; }

        // -------- abstract methods --------
        public abstract double calculateTotalCost();
        public abstract String determinePriority();
        public abstract String getRescueType();
        public abstract String describeExtraInfo();

        // -------- shared helpers --------
        protected double baseCost() {
            return numberOfRescueDays * dailyCareCost;
        }

        protected static String money(double value) {
            DecimalFormat df = new DecimalFormat("#,##0.00");
            return "R" + df.format(value).replace(",", " ");
        }
    }

    // ============================================================
   
    public static class InjuredAnimalRescue extends RescueCase {

        private String injuryDescription;
        private double veterinaryTreatmentCost;
        private boolean surgeryRequired;

        public InjuredAnimalRescue(String id, String name, String species,
                                   String location, String ranger,
                                   int days, double dailyCost, String status,
                                   String injuryDescription,
                                   double veterinaryTreatmentCost,
                                   boolean surgeryRequired) {
            super(id, name, species, location, ranger, days, dailyCost, status);
            this.injuryDescription = injuryDescription;
            this.veterinaryTreatmentCost = veterinaryTreatmentCost;
            this.surgeryRequired = surgeryRequired;
        }

        public String getInjuryDescription() { return injuryDescription; }
        public void setInjuryDescription(String v) { this.injuryDescription = v; }

        public double getVeterinaryTreatmentCost() { return veterinaryTreatmentCost; }
        public void setVeterinaryTreatmentCost(double v) { this.veterinaryTreatmentCost = v; }

        public boolean isSurgeryRequired() { return surgeryRequired; }
        public void setSurgeryRequired(boolean v) { this.surgeryRequired = v; }

        @Override
        public double calculateTotalCost() {
            double total = baseCost() + veterinaryTreatmentCost;
            if (surgeryRequired) total += 5000.00;
            return total;
        }

        @Override
        public String determinePriority() {
            if (surgeryRequired && veterinaryTreatmentCost >= 12000) return "Critical";
            if (surgeryRequired || veterinaryTreatmentCost >= 12000) return "High";
            if (veterinaryTreatmentCost >= 4000)                     return "Medium";
            return "Low";
        }

        @Override
        public String getRescueType() { return "Injured Animal Rescue"; }

        @Override
        public String describeExtraInfo() {
            return "Injury Description    : " + injuryDescription + "\n" +
                   "Veterinary Cost       : " + money(veterinaryTreatmentCost) + "\n" +
                   "Surgery Required      : " + (surgeryRequired ? "Yes" : "No");
        }

        @Override public void startRescue()    { setCurrentRescueStatus(STATUS_IN_PROGRESS); }
        @Override public void completeRescue() { setCurrentRescueStatus(STATUS_COMPLETED); }

        @Override
        public String generateSummary() {
            return "Rescue Case ID     : " + getRescueCaseId() + "\n" +
                   "Rescue Type        : " + getRescueType() + "\n" +
                   "Species            : " + getSpecies() + "\n" +
                   "Assigned Ranger    : " + getAssignedRanger() + "\n" +
                   "Rescue Priority    : " + determinePriority() + "\n" +
                   "Current Status     : " + getCurrentRescueStatus() + "\n" +
                   "Total Rescue Cost  : " + money(calculateTotalCost());
        }
    }

    
    // SUBCLASS 2 - Orphaned Animal Rescue
   
    public static class OrphanedAnimalRescue extends RescueCase {

        private int estimatedAgeMonths;
        private double feedingCost;
        private boolean fosterCareRequired;

        public OrphanedAnimalRescue(String id, String name, String species,
                                    String location, String ranger,
                                    int days, double dailyCost, String status,
                                    int estimatedAgeMonths,
                                    double feedingCost,
                                    boolean fosterCareRequired) {
            super(id, name, species, location, ranger, days, dailyCost, status);
            this.estimatedAgeMonths = estimatedAgeMonths;
            this.feedingCost = feedingCost;
            this.fosterCareRequired = fosterCareRequired;
        }

        public int getEstimatedAgeMonths() { return estimatedAgeMonths; }
        public void setEstimatedAgeMonths(int v) { this.estimatedAgeMonths = v; }

        public double getFeedingCost() { return feedingCost; }
        public void setFeedingCost(double v) { this.feedingCost = v; }

        public boolean isFosterCareRequired() { return fosterCareRequired; }
        public void setFosterCareRequired(boolean v) { this.fosterCareRequired = v; }

        @Override
        public double calculateTotalCost() {
            double total = baseCost() + feedingCost;
            if (fosterCareRequired) total += 2500.00;
            return total;
        }

        @Override
        public String determinePriority() {
            if (estimatedAgeMonths <= 2 && fosterCareRequired) return "Critical";
            if (estimatedAgeMonths <= 2 || fosterCareRequired) return "High";
            if (estimatedAgeMonths <= 9)                       return "Medium";
            return "Low";
        }

        @Override
        public String getRescueType() { return "Orphaned Animal Rescue"; }

        @Override
        public String describeExtraInfo() {
            return "Estimated Age (months): " + estimatedAgeMonths + "\n" +
                   "Feeding Cost          : " + money(feedingCost) + "\n" +
                   "Foster Care Required  : " + (fosterCareRequired ? "Yes" : "No");
        }

        @Override public void startRescue()    { setCurrentRescueStatus(STATUS_IN_PROGRESS); }
        @Override public void completeRescue() { setCurrentRescueStatus(STATUS_COMPLETED); }

        @Override
        public String generateSummary() {
            return "Rescue Case ID     : " + getRescueCaseId() + "\n" +
                   "Rescue Type        : " + getRescueType() + "\n" +
                   "Species            : " + getSpecies() + "\n" +
                   "Assigned Ranger    : " + getAssignedRanger() + "\n" +
                   "Rescue Priority    : " + determinePriority() + "\n" +
                   "Current Status     : " + getCurrentRescueStatus() + "\n" +
                   "Total Rescue Cost  : " + money(calculateTotalCost());
        }
    }

    // SUBCLASS 3 - Endangered Species Rescue
  
    public static class EndangeredSpeciesRescue extends RescueCase {

        private String conservationClassification;
        private double securityCost;
        private boolean specialistTeamRequired;

        public EndangeredSpeciesRescue(String id, String name, String species,
                                       String location, String ranger,
                                       int days, double dailyCost, String status,
                                       String conservationClassification,
                                       double securityCost,
                                       boolean specialistTeamRequired) {
            super(id, name, species, location, ranger, days, dailyCost, status);
            this.conservationClassification = conservationClassification;
            this.securityCost = securityCost;
            this.specialistTeamRequired = specialistTeamRequired;
        }

        public String getConservationClassification() { return conservationClassification; }
        public void setConservationClassification(String v) { this.conservationClassification = v; }

        public double getSecurityCost() { return securityCost; }
        public void setSecurityCost(double v) { this.securityCost = v; }

        public boolean isSpecialistTeamRequired() { return specialistTeamRequired; }
        public void setSpecialistTeamRequired(boolean v) { this.specialistTeamRequired = v; }

        @Override
        public double calculateTotalCost() {
            double total = baseCost() + securityCost;
            if (specialistTeamRequired) total += 8000.00;
            return total;
        }

        @Override
        public String determinePriority() {
            boolean critical = "Critically Endangered".equalsIgnoreCase(conservationClassification);
            if (specialistTeamRequired && critical)                        return "Critical";
            if (specialistTeamRequired || critical)                        return "High";
            if ("Endangered".equalsIgnoreCase(conservationClassification)) return "Medium";
            return "Low";
        }

        @Override
        public String getRescueType() { return "Endangered Species Rescue"; }

        @Override
        public String describeExtraInfo() {
            return "Classification        : " + conservationClassification + "\n" +
                   "Security Cost         : " + money(securityCost) + "\n" +
                   "Specialist Team       : " + (specialistTeamRequired ? "Yes" : "No");
        }

        @Override public void startRescue()    { setCurrentRescueStatus(STATUS_IN_PROGRESS); }
        @Override public void completeRescue() { setCurrentRescueStatus(STATUS_COMPLETED); }

        @Override
        public String generateSummary() {
            return "Rescue Case ID     : " + getRescueCaseId() + "\n" +
                   "Rescue Type        : " + getRescueType() + "\n" +
                   "Species            : " + getSpecies() + "\n" +
                   "Assigned Ranger    : " + getAssignedRanger() + "\n" +
                   "Rescue Priority    : " + determinePriority() + "\n" +
                   "Current Status     : " + getCurrentRescueStatus() + "\n" +
                   "Total Rescue Cost  : " + money(calculateTotalCost());
        }
    }

   
    public static class RescueManager {

        private final List<RescueCase> orderedCases = new ArrayList<>();
        private final Map<String, RescueCase> indexById = new HashMap<>();

        public void addRescueCase(RescueCase rescueCase) {
            if (rescueCase == null) {
                throw new IllegalArgumentException("Rescue case cannot be null.");
            }
            String id = rescueCase.getRescueCaseId();
            if (id == null || id.trim().isEmpty()) {
                throw new IllegalArgumentException("Rescue Case ID cannot be blank.");
            }
            String key = id.trim().toUpperCase();
            if (indexById.containsKey(key)) {
                throw new IllegalArgumentException("Rescue Case ID already exists: " + id);
            }
            orderedCases.add(rescueCase);
            indexById.put(key, rescueCase);
        }

        public RescueCase findById(String rescueCaseId) {
            if (rescueCaseId == null) return null;
            return indexById.get(rescueCaseId.trim().toUpperCase());
        }

        public boolean updateStatus(String rescueCaseId, String newStatus) {
            RescueCase rc = findById(rescueCaseId);
            if (rc == null) return false;
            rc.setCurrentRescueStatus(newStatus);
            return true;
        }

        public List<RescueCase> getAllCases() {
            return orderedCases;
        }

        public int getCaseCount() {
            return orderedCases.size();
        }

        public double getTotalCost() {
            double sum = 0.0;
            for (RescueCase rc : orderedCases) {
                sum += rc.calculateTotalCost();
            }
            return sum;
        }

        public boolean idExists(String rescueCaseId) {
            return findById(rescueCaseId) != null;
        }
    }

    
    // USER INTERFACE - JOptionPane menu
    
    public static class RescueOperationsUI {

        private static final RescueManager manager = new RescueManager();

        public static void run() {
            boolean running = true;
            while (running) {
                String menu =
                        "=========================================\n" +
                        " WILDLIFE RESCUE OPERATIONS SYSTEM\n" +
                        "=========================================\n" +
                        " 1. Create Rescue Case\n" +
                        " 2. Search Rescue Case\n" +
                        " 3. Update Rescue Status\n" +
                        " 4. Display All Rescue Cases\n" +
                        " 5. Rescue Report\n" +
                        " 6. Exit\n" +
                        "=========================================\n" +
                        " Select an option:";

                String choice = JOptionPane.showInputDialog(
                        null, menu, "WildLife SA", JOptionPane.PLAIN_MESSAGE);

                if (choice == null) { running = false; continue; }

                switch (choice.trim()) {
                    case "1": createCase();    break;
                    case "2": searchCase();    break;
                    case "3": updateStatus();  break;
                    case "4": displayAll();    break;
                    case "5": report();        break;
                    case "6":
                        running = false;
                        info("Thank you. Goodbye!");
                        break;
                    default:
                        warn("Invalid option. Please select 1-6.");
                }
            }
        }

        // ---------- 1. Create ----------
        private static void createCase() {
            String[] types = {
                "Injured Animal Rescue",
                "Orphaned Animal Rescue",
                "Endangered Species Rescue"
            };

            String type = (String) JOptionPane.showInputDialog(
                    null,
                    "Select the type of rescue case:",
                    "WildLife SA - New Rescue Case",
                    JOptionPane.QUESTION_MESSAGE,
                    null, types, types[0]);

            if (type == null) return;

            String id = ask("Enter Rescue Case ID:");
            if (id == null) return;
            if (manager.idExists(id)) { warn("This Rescue Case ID already exists."); return; }

            String animalName = ask("Enter Animal Name:");      if (animalName == null) return;
            String species    = ask("Enter Species:");          if (species == null) return;
            String location   = ask("Enter Rescue Location:");  if (location == null) return;
            String ranger     = ask("Enter Assigned Ranger:");  if (ranger == null) return;
            Integer days      = askPositiveInt("Enter Number of Rescue Days:");    if (days == null) return;
            Double dailyCost  = askPositiveDouble("Enter Daily Care Cost (R):");   if (dailyCost == null) return;

            RescueCase rc = null;

            try {
                if (type.equals("Injured Animal Rescue")) {
                    String injury = ask("Enter Injury Description:"); if (injury == null) return;
                    Double vet    = askNonNegativeDouble("Enter Veterinary Treatment Cost (R):"); if (vet == null) return;
                    Boolean surg  = askYesNo("Is Surgery Required?");
                    rc = new InjuredAnimalRescue(id, animalName, species, location, ranger,
                                                 days, dailyCost, RescueOperations.STATUS_NEW,
                                                 injury, vet, surg);
                } else if (type.equals("Orphaned Animal Rescue")) {
                    Integer age     = askPositiveInt("Enter Estimated Age (Months):"); if (age == null) return;
                    Double feeding  = askNonNegativeDouble("Enter Feeding Cost (R):"); if (feeding == null) return;
                    Boolean foster  = askYesNo("Is Foster Care Required?");
                    rc = new OrphanedAnimalRescue(id, animalName, species, location, ranger,
                                                  days, dailyCost, RescueOperations.STATUS_NEW,
                                                  age, feeding, foster);
                } else {
                    String cls       = ask("Enter Conservation Classification:"); if (cls == null) return;
                    Double security  = askNonNegativeDouble("Enter Security Cost (R):"); if (security == null) return;
                    Boolean spec     = askYesNo("Is a Specialist Team Required?");
                    rc = new EndangeredSpeciesRescue(id, animalName, species, location, ranger,
                                                     days, dailyCost, RescueOperations.STATUS_NEW,
                                                     cls, security, spec);
                }

                manager.addRescueCase(rc);
                info("Rescue case created successfully.\n\n" + rc.generateSummary());

            } catch (IllegalArgumentException ex) {
                warn(ex.getMessage());
            }
        }

        // ---------- 2. Search ----------
        private static void searchCase() {
            String id = ask("Enter Rescue Case ID to search:");
            if (id == null) return;

            RescueCase rc = manager.findById(id);
            if (rc == null) {
                warn("No rescue case found with ID: " + id);
                return;
            }
            showLong("Rescue Case Details", fullDetails(rc));
        }

        // ---------- 3. Update status ----------
        private static void updateStatus() {
            String id = ask("Enter Rescue Case ID to update:");
            if (id == null) return;

            RescueCase rc = manager.findById(id);
            if (rc == null) { warn("No rescue case found with ID: " + id); return; }

            String[] options = {
                RescueOperations.STATUS_IN_PROGRESS,
                RescueOperations.STATUS_OBSERVATION,
                RescueOperations.STATUS_COMPLETED,
                RescueOperations.STATUS_NEW
            };

            String newStatus = (String) JOptionPane.showInputDialog(
                    null,
                    "Select the new status for " + rc.getRescueCaseId() + ":",
                    "Update Rescue Status",
                    JOptionPane.QUESTION_MESSAGE,
                    null, options, rc.getCurrentRescueStatus());

            if (newStatus == null) return;

            manager.updateStatus(id, newStatus);
            info("Status updated.\n\n" + rc.generateSummary());
        }

        // ---------- 4. Display all ----------
        private static void displayAll() {
            List<RescueCase> all = manager.getAllCases();
            if (all.isEmpty()) { info("No rescue cases have been captured yet."); return; }

            StringBuilder sb = new StringBuilder();
            sb.append("ALL RESCUE CASES (").append(all.size()).append(")\n");
            sb.append("==================================================\n");
            for (RescueCase rc : all) {
                sb.append(fullDetails(rc)).append("\n");
                sb.append("--------------------------------------------------\n");
            }
            showLong("All Rescue Cases", sb.toString());
        }

        // ---------- 5. Report ----------
        private static void report() {
            List<RescueCase> all = manager.getAllCases();

            StringBuilder sb = new StringBuilder();
            sb.append("==================================================\n");
            sb.append("WILDLIFE RESCUE REPORT\n");
            sb.append("==================================================\n");

            if (all.isEmpty()) {
                sb.append("No rescue cases to report.\n");
            } else {
                for (RescueCase rc : all) {
                    sb.append("Case ID          : ").append(rc.getRescueCaseId()).append("\n");
                    sb.append("Type             : ").append(rc.getRescueType()).append("\n");
                    sb.append("Species          : ").append(rc.getSpecies()).append("\n");
                    sb.append("Rescue Location  : ").append(rc.getRescueLocation()).append("\n");
                    sb.append("Assigned Ranger  : ").append(rc.getAssignedRanger()).append("\n");
                    sb.append("Priority         : ").append(rc.determinePriority()).append("\n");
                    sb.append("Status           : ").append(rc.getCurrentRescueStatus()).append("\n");
                    sb.append("Total Cost       : ").append(RescueCase.money(rc.calculateTotalCost())).append("\n");
                    sb.append("--------------------------------------------------\n");
                }
            }

            sb.append("==================================================\n");
            sb.append("Total Rescue Cases : ").append(manager.getCaseCount()).append("\n");
            sb.append("Total Rescue Cost  : ").append(RescueCase.money(manager.getTotalCost())).append("\n");
            sb.append("==================================================\n");

            showLong("Wildlife Rescue Report", sb.toString());
        }

        // ---------- helpers ----------
        private static String fullDetails(RescueCase rc) {
            return "Rescue Case ID        : " + rc.getRescueCaseId() + "\n" +
                   "Animal Name           : " + rc.getAnimalName() + "\n" +
                   "Rescue Type           : " + rc.getRescueType() + "\n" +
                   "Species               : " + rc.getSpecies() + "\n" +
                   "Rescue Location       : " + rc.getRescueLocation() + "\n" +
                   "Assigned Ranger       : " + rc.getAssignedRanger() + "\n" +
                   "Number of Rescue Days : " + rc.getNumberOfRescueDays() + "\n" +
                   "Daily Care Cost       : " + RescueCase.money(rc.getDailyCareCost()) + "\n" +
                   "Current Status        : " + rc.getCurrentRescueStatus() + "\n" +
                   "Rescue Priority       : " + rc.determinePriority() + "\n" +
                   rc.describeExtraInfo() + "\n" +
                   "Total Rescue Cost     : " + RescueCase.money(rc.calculateTotalCost()) + "\n";
        }

        private static void showLong(String title, String content) {
            JTextArea area = new JTextArea(content);
            area.setEditable(false);
            area.setFont(new java.awt.Font("Monospaced", java.awt.Font.PLAIN, 12));
            JScrollPane scroll = new JScrollPane(area);
            scroll.setPreferredSize(new Dimension(560, 440));
            JOptionPane.showMessageDialog(null, scroll, title, JOptionPane.INFORMATION_MESSAGE);
        }

        private static String ask(String prompt) {
            while (true) {
                String s = JOptionPane.showInputDialog(null, prompt, "WildLife SA - Input", JOptionPane.QUESTION_MESSAGE);
                if (s == null) return null;
                if (!s.trim().isEmpty()) return s.trim();
                warn("Input cannot be blank.");
            }
        }

        private static Integer askPositiveInt(String prompt) {
            while (true) {
                String s = JOptionPane.showInputDialog(null, prompt, "WildLife SA - Input", JOptionPane.QUESTION_MESSAGE);
                if (s == null) return null;
                try {
                    int v = Integer.parseInt(s.trim());
                    if (v > 0) return v;
                    warn("Value must be greater than zero.");
                } catch (NumberFormatException e) {
                    warn("Please enter a valid whole number.");
                }
            }
        }

        private static Double askPositiveDouble(String prompt) {
            while (true) {
                String s = JOptionPane.showInputDialog(null, prompt, "WildLife SA - Input", JOptionPane.QUESTION_MESSAGE);
                if (s == null) return null;
                try {
                    double v = Double.parseDouble(s.trim());
                    if (v > 0) return v;
                    warn("Value must be greater than zero.");
                } catch (NumberFormatException e) {
                    warn("Please enter a valid number.");
                }
            }
        }

        private static Double askNonNegativeDouble(String prompt) {
            while (true) {
                String s = JOptionPane.showInputDialog(null, prompt, "WildLife SA - Input", JOptionPane.QUESTION_MESSAGE);
                if (s == null) return null;
                try {
                    double v = Double.parseDouble(s.trim());
                    if (v >= 0) return v;
                    warn("Value cannot be negative.");
                } catch (NumberFormatException e) {
                    warn("Please enter a valid number.");
                }
            }
        }

        private static Boolean askYesNo(String prompt) {
            int result = JOptionPane.showConfirmDialog(
                    null, prompt, "WildLife SA", JOptionPane.YES_NO_OPTION);
            return result == JOptionPane.YES_OPTION;
        }

        private static void info(String msg) {
            JOptionPane.showMessageDialog(null, msg, "WildLife SA", JOptionPane.INFORMATION_MESSAGE);
        }

        private static void warn(String msg) {
            JOptionPane.showMessageDialog(null, msg, "WildLife SA", JOptionPane.WARNING_MESSAGE);
        }
    }
}