package com.mycompany.hanan_malik_prog6112_assign_2;

import com.mycompany.hanan_malik_prog6112_assign_2.Hanan_Malik_PROG6112_ASSIGN_2.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class RescueManagerTest {

    private RescueManager manager;

    @BeforeEach
    public void setUp() {
        manager = new RescueManager();
    }

    // ---------- COST ----------

    @Test
    public void testInjuredWithoutSurgery() {
        InjuredAnimalRescue r = new InjuredAnimalRescue(
            "WR101", "Tusker", "African Elephant", "Kruger", "Ranger A",
            5, 2000.00, RescueOperations.STATUS_NEW,
            "Snare wound", 8500.00, false);
        // 5*2000 = 10000 + 8500 = 18500
        assertEquals(18500.00, r.calculateTotalCost(), 0.001);
    }

    @Test
    public void testInjuredWithSurgery() {
        InjuredAnimalRescue r = new InjuredAnimalRescue(
            "WR102", "Tusker", "African Elephant", "Kruger", "Ranger A",
            5, 2000.00, RescueOperations.STATUS_NEW,
            "Snare wound", 8500.00, true);
        // 10000 + 8500 + 5000 = 23500
        assertEquals(23500.00, r.calculateTotalCost(), 0.001);
    }

    @Test
    public void testOrphanedWithoutFoster() {
        OrphanedAnimalRescue r = new OrphanedAnimalRescue(
            "WR103", "Nandi", "White Rhino", "Hluhluwe", "Ranger B",
            10, 600.00, RescueOperations.STATUS_NEW,
            4, 3000.00, false);
        // 6000 + 3000 = 9000
        assertEquals(9000.00, r.calculateTotalCost(), 0.001);
    }

    @Test
    public void testOrphanedWithFoster() {
        OrphanedAnimalRescue r = new OrphanedAnimalRescue(
            "WR104", "Nandi", "White Rhino", "Hluhluwe", "Ranger B",
            10, 600.00, RescueOperations.STATUS_NEW,
            4, 3000.00, true);
        // 6000 + 3000 + 2500 = 11500
        assertEquals(11500.00, r.calculateTotalCost(), 0.001);
    }

    @Test
    public void testEndangeredWithoutSpecialist() {
        EndangeredSpeciesRescue r = new EndangeredSpeciesRescue(
            "WR105", "Shadow", "Black Rhino", "Addo", "Ranger C",
            7, 800.00, RescueOperations.STATUS_NEW,
            "Critically Endangered", 12000.00, false);
        // 5600 + 12000 = 17600
        assertEquals(17600.00, r.calculateTotalCost(), 0.001);
    }

    @Test
    public void testEndangeredWithSpecialist() {
        EndangeredSpeciesRescue r = new EndangeredSpeciesRescue(
            "WR106", "Shadow", "Black Rhino", "Addo", "Ranger C",
            7, 800.00, RescueOperations.STATUS_NEW,
            "Critically Endangered", 12000.00, true);
        // 5600 + 12000 + 8000 = 25600
        assertEquals(25600.00, r.calculateTotalCost(), 0.001);
    }

    // ---------- PRIORITY ----------

    @Test
    public void testInjuredPriorityCritical() {
        InjuredAnimalRescue r = new InjuredAnimalRescue(
            "WR107", "Lion", "African Lion", "Kgalagadi", "Ranger D",
            3, 500.00, RescueOperations.STATUS_NEW,
            "Gunshot", 15000.00, true);
        assertEquals("Critical", r.determinePriority());
    }

    @Test
    public void testInjuredPriorityHigh() {
        InjuredAnimalRescue r = new InjuredAnimalRescue(
            "WR108", "Lion", "African Lion", "Kgalagadi", "Ranger D",
            3, 500.00, RescueOperations.STATUS_NEW,
            "Fracture", 13000.00, false);
        assertEquals("High", r.determinePriority());
    }

    @Test
    public void testInjuredPriorityMedium() {
        InjuredAnimalRescue r = new InjuredAnimalRescue(
            "WR109", "Lion", "African Lion", "Kgalagadi", "Ranger D",
            3, 500.00, RescueOperations.STATUS_NEW,
            "Wound", 5000.00, false);
        assertEquals("Medium", r.determinePriority());
    }

    @Test
    public void testInjuredPriorityLow() {
        InjuredAnimalRescue r = new InjuredAnimalRescue(
            "WR110", "Lion", "African Lion", "Kgalagadi", "Ranger D",
            3, 500.00, RescueOperations.STATUS_NEW,
            "Cut", 1000.00, false);
        assertEquals("Low", r.determinePriority());
    }

    @Test
    public void testOrphanedPriorityCritical() {
        OrphanedAnimalRescue r = new OrphanedAnimalRescue(
            "WR111", "Baby Elephant", "African Elephant", "Addo", "Ranger E",
            5, 400.00, RescueOperations.STATUS_NEW,
            2, 3000.00, true);
        assertEquals("Critical", r.determinePriority());
    }

    @Test
    public void testOrphanedPriorityHigh() {
        OrphanedAnimalRescue r = new OrphanedAnimalRescue(
            "WR112", "Baby Elephant", "African Elephant", "Addo", "Ranger E",
            5, 400.00, RescueOperations.STATUS_NEW,
            2, 3000.00, false);
        assertEquals("High", r.determinePriority());
    }

    @Test
    public void testOrphanedPriorityMedium() {
        OrphanedAnimalRescue r = new OrphanedAnimalRescue(
            "WR113", "Young Elephant", "African Elephant", "Addo", "Ranger E",
            5, 400.00, RescueOperations.STATUS_NEW,
            8, 3000.00, false);
        assertEquals("Medium", r.determinePriority());
    }

    @Test
    public void testOrphanedPriorityLow() {
        OrphanedAnimalRescue r = new OrphanedAnimalRescue(
            "WR114", "Juvenile Elephant", "African Elephant", "Addo", "Ranger E",
            5, 400.00, RescueOperations.STATUS_NEW,
            18, 3000.00, false);
        assertEquals("Low", r.determinePriority());
    }

    @Test
    public void testEndangeredPriorityCritical() {
        EndangeredSpeciesRescue r = new EndangeredSpeciesRescue(
            "WR115", "Rhino", "Black Rhino", "Kruger", "Ranger F",
            6, 600.00, RescueOperations.STATUS_NEW,
            "Critically Endangered", 9000.00, true);
        assertEquals("Critical", r.determinePriority());
    }

    @Test
    public void testEndangeredPriorityHigh() {
        EndangeredSpeciesRescue r = new EndangeredSpeciesRescue(
            "WR116", "Rhino", "Black Rhino", "Kruger", "Ranger F",
            6, 600.00, RescueOperations.STATUS_NEW,
            "Critically Endangered", 9000.00, false);
        assertEquals("High", r.determinePriority());
    }

    @Test
    public void testEndangeredPriorityMedium() {
        EndangeredSpeciesRescue r = new EndangeredSpeciesRescue(
            "WR117", "Rhino", "Black Rhino", "Kruger", "Ranger F",
            6, 600.00, RescueOperations.STATUS_NEW,
            "Endangered", 9000.00, false);
        assertEquals("Medium", r.determinePriority());
    }

    @Test
    public void testEndangeredPriorityLow() {
        EndangeredSpeciesRescue r = new EndangeredSpeciesRescue(
            "WR118", "Rhino", "Black Rhino", "Kruger", "Ranger F",
            6, 600.00, RescueOperations.STATUS_NEW,
            "Vulnerable", 9000.00, false);
        assertEquals("Low", r.determinePriority());
    }

    // ---------- STATUS ----------

    @Test
    public void testStartRescue() {
        InjuredAnimalRescue r = new InjuredAnimalRescue(
            "WR119", "Zebra", "Plains Zebra", "Etosha", "Ranger G",
            4, 150.00, RescueOperations.STATUS_NEW,
            "Sprain", 1200.00, false);
        r.startRescue();
        assertEquals(RescueOperations.STATUS_IN_PROGRESS, r.getCurrentRescueStatus());
    }

    @Test
    public void testCompleteRescue() {
        OrphanedAnimalRescue r = new OrphanedAnimalRescue(
            "WR120", "Baby Giraffe", "Giraffe", "Etosha", "Ranger G",
            4, 150.00, RescueOperations.STATUS_NEW,
            4, 800.00, false);
        r.completeRescue();
        assertEquals(RescueOperations.STATUS_COMPLETED, r.getCurrentRescueStatus());
    }

    // ---------- SEARCH ----------

    @Test
    public void testSearchExisting() {
        InjuredAnimalRescue r = new InjuredAnimalRescue(
            "WR121", "Leopard", "African Leopard", "Sabie", "Ranger H",
            2, 250.00, RescueOperations.STATUS_NEW,
            "Snare", 3000.00, false);
        manager.addRescueCase(r);

        RescueCase found = manager.findById("WR121");
        assertNotNull(found);
        assertEquals("WR121", found.getRescueCaseId());
        assertEquals("Leopard", found.getAnimalName());
    }

    @Test
    public void testSearchNonExisting() {
        assertNull(manager.findById("WR999"));
    }

    @Test
    public void testSearchIsCaseInsensitive() {
        OrphanedAnimalRescue r = new OrphanedAnimalRescue(
            "wr122", "Baby Lion", "African Lion", "Kgalagadi", "Ranger I",
            3, 200.00, RescueOperations.STATUS_NEW,
            2, 900.00, true);
        manager.addRescueCase(r);

        assertNotNull(manager.findById("WR122"));
    }

    // ---------- DUPLICATE IDS / VALIDATION ----------

    @Test
    public void testPreventDuplicateId() {
        InjuredAnimalRescue r1 = new InjuredAnimalRescue(
            "WR123", "Buffalo", "African Buffalo", "Hluhluwe", "Ranger J",
            5, 180.00, RescueOperations.STATUS_NEW,
            "Broken horn", 2500.00, false);
        manager.addRescueCase(r1);

        InjuredAnimalRescue r2 = new InjuredAnimalRescue(
            "WR123", "Buffalo", "African Buffalo", "Hluhluwe", "Ranger J",
            5, 180.00, RescueOperations.STATUS_NEW,
            "Broken horn", 2500.00, false);

        assertThrows(IllegalArgumentException.class, () -> manager.addRescueCase(r2));
    }

    @Test
    public void testPreventDuplicateCaseInsensitive() {
        EndangeredSpeciesRescue r1 = new EndangeredSpeciesRescue(
            "WR124", "Pangolin", "Ground Pangolin", "Limpopo", "Ranger K",
            4, 350.00, RescueOperations.STATUS_NEW,
            "Endangered", 3000.00, false);
        manager.addRescueCase(r1);

        EndangeredSpeciesRescue r2 = new EndangeredSpeciesRescue(
            "wr124", "Pangolin", "Ground Pangolin", "Limpopo", "Ranger K",
            4, 350.00, RescueOperations.STATUS_NEW,
            "Endangered", 3000.00, false);

        assertThrows(IllegalArgumentException.class, () -> manager.addRescueCase(r2));
    }

    @Test
    public void testBlankIdRejected() {
        InjuredAnimalRescue r = new InjuredAnimalRescue(
            "   ", "Bird", "Eagle", "Drakensberg", "Ranger L",
            2, 100.00, RescueOperations.STATUS_NEW,
            "Wing", 500.00, false);
        assertThrows(IllegalArgumentException.class, () -> manager.addRescueCase(r));
    }

    @Test
    public void testNullCaseRejected() {
        assertThrows(IllegalArgumentException.class, () -> manager.addRescueCase(null));
    }

    // ---------- AGGREGATES ----------

    @Test
    public void testTotalCasesAndTotalCost() {
        InjuredAnimalRescue r1 = new InjuredAnimalRescue(
            "WR125", "Elephant", "African Elephant", "Kruger", "Ranger A",
            5, 100.00, RescueOperations.STATUS_NEW,
            "Broken leg", 2000.00, false); // 2500

        OrphanedAnimalRescue r2 = new OrphanedAnimalRescue(
            "WR126", "Baby Rhino", "White Rhino", "Hluhluwe", "Ranger B",
            10, 200.00, RescueOperations.STATUS_NEW,
            6, 1500.00, true); // 2000 + 1500 + 2500 = 6000

        manager.addRescueCase(r1);
        manager.addRescueCase(r2);

        assertEquals(2, manager.getCaseCount());
        assertEquals(8500.00, manager.getTotalCost(), 0.001);
    }
}